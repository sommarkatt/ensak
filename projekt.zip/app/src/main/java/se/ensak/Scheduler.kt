package se.ensak

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar
import kotlin.random.Random

object Scheduler {
    const val START_HOUR = 9
    const val END_HOUR = 20

    fun scheduleNext(c: Context, delayMs: Long? = null) {
        val at = delayMs?.let { System.currentTimeMillis() + it } ?: nextRandomTime()
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            c, 1, Intent(c, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val canExact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (canExact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
        c.getSharedPreferences("ensak", Context.MODE_PRIVATE).edit().putLong("nextAt", at).apply()
    }

    fun ensureScheduled(c: Context) {
        val next = c.getSharedPreferences("ensak", Context.MODE_PRIVATE).getLong("nextAt", 0L)
        if (next < System.currentTimeMillis()) scheduleNext(c)
    }

    private fun nextRandomTime(): Long {
        val now = Calendar.getInstance()
        val candidate = now.clone() as Calendar
        candidate.add(Calendar.MINUTE, 90 + Random.nextInt(150)) // 1,5–4 timmar framåt
        if (candidate.get(Calendar.HOUR_OF_DAY) in START_HOUR until END_HOUR &&
            candidate.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
        ) return candidate.timeInMillis

        val tomorrow = Calendar.getInstance()
        tomorrow.add(Calendar.DAY_OF_YEAR, 1)
        tomorrow.set(Calendar.HOUR_OF_DAY, START_HOUR + Random.nextInt(END_HOUR - START_HOUR))
        tomorrow.set(Calendar.MINUTE, Random.nextInt(60))
        tomorrow.set(Calendar.SECOND, 0)
        return tomorrow.timeInMillis
    }
}
