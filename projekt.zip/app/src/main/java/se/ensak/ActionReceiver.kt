package se.ensak

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        when (intent.action) {
            DONE -> {
                TaskStore.remove(c, id)
                Scheduler.scheduleNext(c)
            }
            SNOOZE -> {
                c.getSharedPreferences("ensak", Context.MODE_PRIVATE)
                    .edit().putLong("forcedId", id).apply()
                Scheduler.scheduleNext(c, 60L * 60 * 1000)
            }
        }
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(AlarmReceiver.NOTIF_ID)
    }

    companion object {
        const val DONE = "se.ensak.DONE"
        const val SNOOZE = "se.ensak.SNOOZE"
    }
}
