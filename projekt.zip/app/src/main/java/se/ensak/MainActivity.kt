package se.ensak

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.TypedValue
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Scheduler.ensureScheduled(this)

        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val bg = "#14333A"; val ink = "#E9E4D6"; val muted = "#9DB8BA"; val accent = "#F2A65A"

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(40), dp(28), dp(40))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor(bg))
            addView(col)
        }

        fun label(s: String, size: Float, c: String, padTop: Int = 0) {
            col.addView(TextView(this).apply {
                text = s
                setTextColor(Color.parseColor(c))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
                setPadding(0, dp(padTop), 0, dp(8))
            })
        }

        fun btn(s: String, onClick: () -> Unit) {
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, dp(6), 0, dp(6))
            col.addView(Button(this).apply {
                text = s
                isAllCaps = false
                setTextColor(Color.parseColor("#27201A"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                background = GradientDrawable().apply {
                    cornerRadius = dp(24).toFloat()
                    setColor(Color.parseColor(accent))
                }
                setPadding(dp(20), dp(12), dp(20), dp(12))
                setOnClickListener { onClick() }
            }, lp)
        }

        label("En sak", 34f, ink)
        label("Gör klart stegen nedan en gång. Sen behöver du aldrig öppna appen igen — den hör av sig själv.", 16f, muted)

        label("1. Släpp in saker", 20f, ink, 16)
        val input = EditText(this).apply {
            hint = "Skriv en sak …"
            setHintTextColor(Color.parseColor(muted))
            setTextColor(Color.parseColor(ink))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        }
        col.addView(input)
        btn("Lägg till") {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) {
                TaskStore.add(this, t)
                input.setText("")
                Toast.makeText(this, "Släppt.", Toast.LENGTH_SHORT).show()
            }
        }
        label("Du kan också dela text från vilken app som helst till \"En sak\".", 14f, muted)

        label("2. Ge behörigheter", 20f, ink, 16)
        btn("Tillåt notiser") {
            if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            else Toast.makeText(this, "Redan på.", Toast.LENGTH_SHORT).show()
        }
        btn("Tillåt att ta över skärmen") {
            try {
                if (Build.VERSION.SDK_INT >= 34)
                    startActivity(Intent(
                        Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:$packageName")
                    ))
                else Toast.makeText(this, "Redan på.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Hittar inte inställningen på den här enheten.", Toast.LENGTH_SHORT).show()
            }
        }
        btn("Stäng av batterioptimering") {
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                if (pm.isIgnoringBatteryOptimizations(packageName))
                    Toast.makeText(this, "Redan av.", Toast.LENGTH_SHORT).show()
                else startActivity(Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                ))
            } catch (e: Exception) {
                Toast.makeText(this, "Hittar inte inställningen.", Toast.LENGTH_SHORT).show()
            }
        }

        label("3. Testa", 20f, ink, 16)
        btn("Hör av dig nu") {
            val task = TaskStore.random(this)
            if (task == null) Toast.makeText(this, "Lägg till en sak först.", Toast.LENGTH_SHORT).show()
            else AlarmReceiver.show(this, task)
        }
        label("Sen är det klart. Appen väljer själv när den hör av sig, mellan 09 och 20.", 14f, muted)

        setContentView(scroll)
    }
}
