package se.ensak

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

class ShareActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT)
        if (!text.isNullOrBlank()) {
            TaskStore.add(this, text)
            Scheduler.ensureScheduled(this)
            Toast.makeText(this, "Släppt. Jag hör av mig.", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
