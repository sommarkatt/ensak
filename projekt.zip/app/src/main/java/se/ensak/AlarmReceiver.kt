package se.ensak

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val prefs = c.getSharedPreferences("ensak", Context.MODE_PRIVATE)
        val forced = prefs.getLong("forcedId", -1L)
        if (forced != -1L) prefs.edit().remove("forcedId").apply()
        val task = (if (forced != -1L) TaskStore.byId(c, forced) else null) ?: TaskStore.random(c)
        if (task == null) { Scheduler.scheduleNext(c); return }
        show(c, task)
        Scheduler.scheduleNext(c)
    }

    companion object {
        const val CHANNEL = "ping"
        const val NOTIF_ID = 7

        fun show(c: Context, task: Task) {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CHANNEL, "En sak", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "En sak i taget"
            nm.createNotificationChannel(ch)

            fun action(act: String, req: Int): PendingIntent = PendingIntent.getBroadcast(
                c, req,
                Intent(c, ActionReceiver::class.java).setAction(act).putExtra("id", task.id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val full = PendingIntent.getActivity(
                c, 3,
                Intent(c, FullScreenActivity::class.java)
                    .putExtra("id", task.id)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val n = NotificationCompat.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_leaf)
                .setContentTitle("En sak. Bara den här.")
                .setContentText(task.text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(task.text))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setFullScreenIntent(full, true)
                .setContentIntent(full)
                .setAutoCancel(true)
                .addAction(0, "Klar", action(ActionReceiver.DONE, 11))
                .addAction(0, "Om en timme", action(ActionReceiver.SNOOZE, 12))
                .build()
            nm.notify(NOTIF_ID, n)
        }
    }
}
