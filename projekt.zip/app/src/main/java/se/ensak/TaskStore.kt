package se.ensak

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Task(val id: Long, val text: String, val added: Long)

object TaskStore {
    private const val PREFS = "ensak"
    private const val KEY = "tasks"
    private const val EXPIRE_MS = 10L * 24 * 60 * 60 * 1000 // tyst utgång efter 10 dagar

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Task> {
        val now = System.currentTimeMillis()
        val arr = try { JSONArray(prefs(c).getString(KEY, "[]")) } catch (e: Exception) { JSONArray() }
        val list = mutableListOf<Task>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val added = o.optLong("added")
            if (now - added < EXPIRE_MS) list.add(Task(o.optLong("id"), o.optString("text"), added))
        }
        save(c, list)
        return list
    }

    fun add(c: Context, text: String) {
        val list = all(c)
        list.add(Task(System.currentTimeMillis(), text.trim(), System.currentTimeMillis()))
        save(c, list)
    }

    fun remove(c: Context, id: Long) = save(c, all(c).filter { it.id != id })

    fun byId(c: Context, id: Long): Task? = all(c).firstOrNull { it.id == id }

    fun random(c: Context): Task? = all(c).randomOrNull()

    private fun save(c: Context, list: List<Task>) {
        val arr = JSONArray()
        list.forEach { t -> arr.put(JSONObject().put("id", t.id).put("text", t.text).put("added", t.added)) }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }
}
