package se.ensak

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar

class FullScreenActivity : Activity() {

    private data class Pal(val bg: String, val ink: String, val muted: String, val accent: String, val accentInk: String)

    private val palettes = listOf(
        Pal("#14333A", "#E9E4D6", "#9DB8BA", "#F2A65A", "#27201A"),
        Pal("#E7EDF2", "#23323C", "#5F7580", "#2A6B57", "#F0F6F1"),
        Pal("#211F29", "#D8D4E8", "#8F8AA6", "#8FC7A2", "#1B241D"),
        Pal("#F2ECF3", "#2E2438", "#77688A", "#6D4A8F", "#F5EFFA")
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }

        val task = TaskStore.byId(this, intent.getLongExtra("id", -1L))
        if (task == null) { finish(); return }

        val p = palettes[(Calendar.getInstance().get(Calendar.DAY_OF_YEAR) / 3) % palettes.size]
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor(p.bg))
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }

        val kicker = TextView(this).apply {
            text = "En sak. Bara den här."
            setTextColor(Color.parseColor(p.muted))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            gravity = Gravity.CENTER
        }

        val big = TextView(this).apply {
            text = task.text
            setTextColor(Color.parseColor(p.ink))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 40f)
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(40))
        }

        fun pill(label: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setTextColor(Color.parseColor(if (filled) p.accentInk else p.ink))
            background = GradientDrawable().apply {
                cornerRadius = dp(32).toFloat()
                if (filled) setColor(Color.parseColor(p.accent))
                else { setColor(Color.TRANSPARENT); setStroke(dp(2), Color.parseColor(p.accent)) }
            }
            setPadding(dp(32), dp(16), dp(32), dp(16))
            setOnClickListener { onClick() }
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(dp(8), 0, dp(8), 0)

        row.addView(pill("Klar", true) {
            TaskStore.remove(this, task.id)
            closeUp(reschedule = true)
        }, lp)
        row.addView(pill("Om en timme", false) {
            getSharedPreferences("ensak", Context.MODE_PRIVATE)
                .edit().putLong("forcedId", task.id).apply()
            Scheduler.scheduleNext(this, 60L * 60 * 1000)
            closeUp(reschedule = false)
        }, lp)

        root.addView(kicker)
        root.addView(big)
        root.addView(row)
        setContentView(root)
    }

    private fun closeUp(reschedule: Boolean) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(AlarmReceiver.NOTIF_ID)
        if (reschedule) Scheduler.scheduleNext(this)
        finish()
    }
}
